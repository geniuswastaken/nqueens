﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace queens
{

    public partial class Form1 : Form
    {
        public class Queen
        {
            public int x, y;
            public Queen(int i, int j)
            {
                x = i;
                y = j;
            }
        }

        int n, h;
        int rectSize;
        int circleSize;
        bool[,] queenboard;
        SolidBrush wht;
        SolidBrush blk;
        Graphics g;
        List<Queen> queens;

        public Form1()
        {
            InitializeComponent();
        }

        private void drawChessBrd()
        {
            wht = new SolidBrush(Color.Beige);
            blk = new SolidBrush(Color.Bisque);
            g = chessBrd.CreateGraphics();
            n = nTrackBar.Value;
            rectSize = 500 / n;
            chessBrd.SetBounds(12, 12, rectSize * n, rectSize * n);

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i % 2 == 0)
                    {
                        if (j % 2 == 0)
                        {
                            g.FillRectangle(blk, i * rectSize, j * rectSize, rectSize, rectSize);
                        }
                        else
                        {
                            g.FillRectangle(wht, i * rectSize, j * rectSize, rectSize, rectSize);
                        }
                    }
                    else
                    {
                        if (j % 2 == 0)
                        {
                            g.FillRectangle(wht, i * rectSize, j * rectSize, rectSize, rectSize);
                        }
                        else
                        {
                            g.FillRectangle(blk, i * rectSize, j * rectSize, rectSize, rectSize);
                        }
                    }
                }
            }
        }

        private void setQueenPositions()
        {
            queenboard = new bool[n,n];
            queens = new List<Queen>();

            for (int i = 0; i < n; i++)
            {
                Random rnd = new Random();
                int posX = rnd.Next(0, n);
                int posY = rnd.Next(0, n);
                while (queenboard[posX, posY])
                {
                    posX = rnd.Next(0, n);
                    posY = rnd.Next(0, n);
                }
                queenboard[posX, posY] = true;
                queens.Add(new Queen(posX, posY));
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (queenboard[i, j] == true)
                    {
                        g.FillEllipse(new SolidBrush(Color.Black), j * rectSize + rectSize / 4, i * rectSize + rectSize / 4, rectSize / 2, rectSize / 2);
                    }
                }
            }

            h = calculateHeuristics3();
            hLabel.Text = h.ToString();
        }

        private void nTrackBar_ValueChanged(object sender, EventArgs e)
        {
            nLabel.Text = nTrackBar.Value.ToString();
            drawChessBrd();
        }



        private void chessBrd_Paint(object sender, PaintEventArgs e)
        {
            drawChessBrd();
        }

        private void setQueenPos_Click(object sender, EventArgs e)
        {
            drawChessBrd();
            setQueenPositions();
        }

        private int calculateHeuristics()
        {
            foreach (Queen q in queens)
            {
                int i = q.x;
                int j = q.y;

                while (i < n - 1)
                {
                    i++;
                    if (queenboard[i, j] == true)
                    {
                        h++;
                        break;
                    }
                }

                i = q.x;
                j = q.y;
                while (i > 0)
                {
                    i--;
                    if (queenboard[i, j] == true)
                    {
                        h++;
                        break;
                    }
                }

                i = q.x;
                j = q.y;
                while (j < n - 1)
                {
                    j++;
                    if (queenboard[i, j] == true)
                    {
                        h++;
                        break;
                    }
                }

                i = q.x;
                j = q.y;
                while (j > 0)
                {
                    j--;
                    if (queenboard[i, j] == true)
                    {
                        h++;
                        break;
                    }
                }

                i = q.x;
                j = q.y;
                while ((i < n - 1) && (j < n - 1))
                {
                    i++;
                    j++;
                    if (queenboard[i, j] == true)
                    {
                        h++;
                        break;
                    }
                }

                i = q.x;
                j = q.y;
                while ((i > 0) && (j > 0))
                {
                    i--;
                    j--;
                    if (queenboard[i, j] == true)
                    {
                        h++;
                        break;
                    }
                }

                i = q.x;
                j = q.y;
                while ((i < n - 1) && (j > 0))
                {
                    i++;
                    j--;
                    if (queenboard[i, j] == true)
                    {
                        h++;
                        break;
                    }
                }

                i = q.x;
                j = q.y;
                while ((i > 0) && (j < n - 1))
                {
                    i--;
                    j++;
                    if (queenboard[i, j] == true)
                    {
                        h++;
                        break;
                    }
                }
            }
            h = h / 2;

            return h;
        }

        private int calculateHeuristics2()
        {
            h = 0;

            
            for (int i = 0; i < n; i++)
            {
                int counter = 0;
                for (int j = 0; j < n; j++)
                {
                    if (queenboard[i, j])
                        counter++;
                }
                if (counter != 0)
                    h += counter - 1;
            }

            for (int j = 0; j < n; j++)
            {
                int counter = 0;
                for (int i = 0; i < n; i++)
                {
                    if (queenboard[i, j])
                        counter++;
                }
                if (counter != 0)
                    h += counter - 1;
            }

            for(int i = 0; i < n; i++)
            {
                int counter = 0;
                int k = i;
                int j = 0;
                while(j < i)
                {
                    if (queenboard[k, j])
                        counter++;
                    k--;
                    j++;
                }
                if (counter != 0)
                    h += counter - 1;
            }

            for (int i = n; i >= 0; i--)
            {
                int counter = 0;
                int k = i;
                int j = 0;
                while(k < n)
                {
                    if (queenboard[k, j])
                        counter++;
                    k++;
                    j++;
                }
                if (counter != 0)
                    h += counter - 1;
            }

            h /= 2;

            return h;
        }

        private int calculateHeuristics3()
        {
            h = 0;

            for(int i = 0; i < n; i++)
            {
                int counter = 0;
                for(int j = 0; j < n; j++)
                {
                    if (queenboard[i, j] == true)
                        counter++;
                }

                if (counter > 1)
                    h += (counter - 1);
            }

            for (int i = 0; i < n; i++)
            {
                int counter = 0;
                for (int j = 0; j < n; j++)
                {
                    if (queenboard[j, i] == true)
                        counter++;
                }

                if (counter > 1)
                    h += (counter - 1);
            }

            /*for(int i = 0; i < n; i++)
            {
                int counter = 0;
                int k = i;
                int j = 0;
                while(j <= i)
                {
                    if (queenboard[k, j] == true)
                        counter++;

                    k--;
                    j++;
                }

                if (counter > 1)
                    h += (counter - 1);
            }

            for (int j = 1; j < n; j++)
            {
                int counter = 0;
                int k = n - 1;
                int l = j;
                while(k > j)
                {
                    if (queenboard[k, l] == true)
                        counter++;

                    k--;
                    l++;
                }

                if (counter > 1)
                    h += (counter - 1);
            }*/

            return h;
        }
    }
}
