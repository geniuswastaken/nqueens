﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace queens
{

    public partial class Form1 : Form
    {
        public class Queen
        {
            public int x, y;
            public Queen(int i, int j)
            {
                x = i;
                y = j;
            }
        }

        public class Board
        {
            public bool[,] brd;
            public int h;

            public Board(bool[,] brdx, int hx)
            {
                brd = brdx;
                h = hx;
            }
        }

        int n, h;
        int rectSize;
        int circleSize;
        bool[,] queenboard;
        SolidBrush wht;
        SolidBrush blk;
        Graphics g;
        List<Queen> queens;

        public Form1()
        {
            InitializeComponent();
        }

        private void drawChessBrd()
        {
            wht = new SolidBrush(Color.Beige);
            blk = new SolidBrush(Color.Bisque);
            g = chessBrd.CreateGraphics();
            n = nTrackBar.Value;
            rectSize = 500 / n;
            chessBrd.SetBounds(12, 12, rectSize * n, rectSize * n);

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i % 2 == 0)
                    {
                        if (j % 2 == 0)
                        {
                            g.FillRectangle(blk, i * rectSize, j * rectSize, rectSize, rectSize);
                        }
                        else
                        {
                            g.FillRectangle(wht, i * rectSize, j * rectSize, rectSize, rectSize);
                        }
                    }
                    else
                    {
                        if (j % 2 == 0)
                        {
                            g.FillRectangle(wht, i * rectSize, j * rectSize, rectSize, rectSize);
                        }
                        else
                        {
                            g.FillRectangle(blk, i * rectSize, j * rectSize, rectSize, rectSize);
                        }
                    }
                }
            }
        }

        private void setQueenPositions()
        {
            queenboard = new bool[n,n];
            queens = new List<Queen>();

            for (int i = 0; i < n; i++)
            {
                Random rnd = new Random();
                int posX = rnd.Next(0, n);
                int posY = rnd.Next(0, n);
                while (queenboard[posX, posY])
                {
                    posX = rnd.Next(0, n);
                    posY = rnd.Next(0, n);
                }
                queenboard[posX, posY] = true;
                queens.Add(new Queen(posX, posY));
            }

            drawQueens();

            h = calculateHeuristics3(queenboard);
            hLabel.Text = h.ToString();
        }

        private void drawQueens()
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (queenboard[i, j] == true)
                    {
                        g.FillEllipse(new SolidBrush(Color.Black), j * rectSize + rectSize / 4, i * rectSize + rectSize / 4, rectSize / 2, rectSize / 2);
                    }
                }
            }
        }

        private void nTrackBar_ValueChanged(object sender, EventArgs e)
        {
            nLabel.Text = nTrackBar.Value.ToString();
            drawChessBrd();
        }

        private bool[,] genQueenTable(List<Queen> qnlist)
        {
            bool[,] qntable = new bool[n,n];
            foreach(Queen qn in qnlist)
            {
                qntable[qn.x, qn.y] = true;
            }

            return qntable;
        }

        private void chessBrd_Paint(object sender, PaintEventArgs e)
        {
            drawChessBrd();
        }

        private void setQueenPos_Click(object sender, EventArgs e)
        {
            drawChessBrd();
            setQueenPositions();
        }

        private void hcBtn_Click(object sender, EventArgs e)
        {
            hcLabel1.Visible = true;
            hcTb1.Visible = true;
            hcBtn1.Visible = true;
        }

        private void hcBtn1_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    testTb.AppendText(queenboard[i, j].ToString() + " ");
                }
                testTb.AppendText(Environment.NewLine);
            }
            testTb.AppendText(Environment.NewLine);
            testTb.AppendText(Environment.NewLine);

            /*for(int i = 0; i < n; i++)
            {
                testTb.AppendText("queen " + i + ": " + queens[i].x + " " + queens[i].y + Environment.NewLine);
            }*/

            //queenboard = moveQueenL(queens[1]);

            //queenboard[queens[0].x, queens[0].y] = false;
            //queenboard[queens[0].x - 1, queens[0].y] = true;

            if (canMoveQueenU(queens[0], queenboard))
                queenboard = moveQueenU(queens[0], queenboard);

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    testTb.AppendText(queenboard[i, j].ToString() + " ");
                }
                testTb.AppendText(Environment.NewLine);
            }

            drawChessBrd();
            drawQueens();
        }

        private int calculateHeuristics3(bool[,] b)
        {
            h = 0;

            //testTb.Clear();

            for(int i = 0; i < n; i++)
            {
                int rqc = 0;
                for(int j = 0; j < n; j++)
                {
                    if (b[i, j] == true)
                        rqc++;
                }
                //testTb.AppendText("row " + i + " queen count: " + rqc + Environment.NewLine);
                if (rqc > 1)
                    h += (rqc - 1);
            }

            //testTb.AppendText(Environment.NewLine);

            for (int j = 0; j < n; j++)
            {
                int cqc = 0;
                for (int i = 0; i < n; i++)
                {
                    if (b[i, j] == true)
                        cqc++;
                }
                //testTb.AppendText("column " + j + " queen count: " + cqc + Environment.NewLine);
                if (cqc > 1)
                    h += (cqc - 1);
            }

            for(int i = 0; i < n; i++)
            {
                int dr = 0;
                for(int j = 0; j <= i; j++)
                {
                    if (b[i - j, j] == true)
                        dr++;
                }
                //testTb.AppendText("diagonal right " + i + " queen count: " + dr + Environment.NewLine);
                if (dr > 1)
                    h += (dr - 1);
            }

            for(int j = 1; j < n; j++)
            {
                int k = n - 1;
                int l = j;
                int dr = 0;

                while(l < n)
                {
                    if (b[k, l] == true)
                        dr++;

                    k--;
                    l++;
                }
                //testTb.AppendText("diagonal right " + (n - 1 + j).ToString() + " queen count: " + dr + Environment.NewLine);
                if (dr > 1)
                    h += (dr - 1);
            }

            for (int i = 0; i < n; i++)
            {
                int dl = 0;
                int k = n - 1 - i;
                int j = 0;
                while (k < n)
                {
                    if(b[k, j] == true)
                        dl++;

                    k++;
                    j++;
                }
                //testTb.AppendText("diagonal left " + i + " queen count: " + dl + Environment.NewLine);
                if (dl > 1)
                    h += (dl - 1);
            }

            for(int j = 1; j < n; j++)
            {
                int dl = 0;
                int i = 0;
                int l = j;
                while(l < n)
                {
                    if (b[i, l] == true)
                        dl++;

                    i++;
                    l++;
                }
                //testTb.AppendText("diagonal left " + (n + j).ToString() + " queen count: " + dl + Environment.NewLine);
                if (dl > 1)
                    h += (dl - 1);
            }

            return h;
        }

        private bool canMoveQueenU(Queen q, bool[,] b)
        {
            if((q.x + 1 < n) || (b[q.x + 1, q.y] == true))
            {
                return false;
            } else
            {
                return true;
            }
        }

        private bool[,] moveQueenU(Queen q, bool[,] b)
        {
            b[q.x, q.y] = false;
            b[q.x + 1, q.y] = true;
            return b;
        }
    }
}
