﻿namespace queens
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nTrackBar = new System.Windows.Forms.TrackBar();
            this.nLabel = new System.Windows.Forms.Label();
            this.chessBrd = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.setQueenPos = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.hcBtn = new System.Windows.Forms.Button();
            this.saBtn = new System.Windows.Forms.Button();
            this.lbsBtn = new System.Windows.Forms.Button();
            this.gaBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.hLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // nTrackBar
            // 
            this.nTrackBar.LargeChange = 1;
            this.nTrackBar.Location = new System.Drawing.Point(518, 46);
            this.nTrackBar.Maximum = 12;
            this.nTrackBar.Minimum = 4;
            this.nTrackBar.Name = "nTrackBar";
            this.nTrackBar.Size = new System.Drawing.Size(254, 45);
            this.nTrackBar.TabIndex = 0;
            this.nTrackBar.Value = 4;
            this.nTrackBar.ValueChanged += new System.EventHandler(this.nTrackBar_ValueChanged);
            // 
            // nLabel
            // 
            this.nLabel.AutoSize = true;
            this.nLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nLabel.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.nLabel.Location = new System.Drawing.Point(696, 12);
            this.nLabel.Name = "nLabel";
            this.nLabel.Size = new System.Drawing.Size(32, 33);
            this.nLabel.TabIndex = 1;
            this.nLabel.Text = "4";
            // 
            // chessBrd
            // 
            this.chessBrd.Location = new System.Drawing.Point(12, 12);
            this.chessBrd.Name = "chessBrd";
            this.chessBrd.Size = new System.Drawing.Size(500, 500);
            this.chessBrd.TabIndex = 2;
            this.chessBrd.Paint += new System.Windows.Forms.PaintEventHandler(this.chessBrd_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(518, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 31);
            this.label1.TabIndex = 3;
            this.label1.Text = "Choose N:";
            // 
            // setQueenPos
            // 
            this.setQueenPos.Location = new System.Drawing.Point(524, 97);
            this.setQueenPos.Name = "setQueenPos";
            this.setQueenPos.Size = new System.Drawing.Size(248, 23);
            this.setQueenPos.TabIndex = 5;
            this.setQueenPos.Text = "Set Queen Positions";
            this.setQueenPos.UseVisualStyleBackColor = true;
            this.setQueenPos.Click += new System.EventHandler(this.setQueenPos_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(518, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(237, 31);
            this.label2.TabIndex = 7;
            this.label2.Text = "Choose Algorithm:";
            // 
            // hcBtn
            // 
            this.hcBtn.Location = new System.Drawing.Point(524, 189);
            this.hcBtn.Name = "hcBtn";
            this.hcBtn.Size = new System.Drawing.Size(120, 23);
            this.hcBtn.TabIndex = 8;
            this.hcBtn.Text = "Hill Climbing";
            this.hcBtn.UseVisualStyleBackColor = true;
            // 
            // saBtn
            // 
            this.saBtn.Location = new System.Drawing.Point(652, 189);
            this.saBtn.Name = "saBtn";
            this.saBtn.Size = new System.Drawing.Size(120, 23);
            this.saBtn.TabIndex = 9;
            this.saBtn.Text = "Simulated Annealing";
            this.saBtn.UseVisualStyleBackColor = true;
            // 
            // lbsBtn
            // 
            this.lbsBtn.Location = new System.Drawing.Point(524, 218);
            this.lbsBtn.Name = "lbsBtn";
            this.lbsBtn.Size = new System.Drawing.Size(120, 23);
            this.lbsBtn.TabIndex = 10;
            this.lbsBtn.Text = "Local Beam Search";
            this.lbsBtn.UseVisualStyleBackColor = true;
            // 
            // gaBtn
            // 
            this.gaBtn.Location = new System.Drawing.Point(652, 218);
            this.gaBtn.Name = "gaBtn";
            this.gaBtn.Size = new System.Drawing.Size(120, 23);
            this.gaBtn.TabIndex = 11;
            this.gaBtn.Text = "Genetic Algorithm";
            this.gaBtn.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(521, 254);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Heuristics: ";
            // 
            // hLabel
            // 
            this.hLabel.AutoSize = true;
            this.hLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hLabel.Location = new System.Drawing.Point(614, 251);
            this.hLabel.Name = "hLabel";
            this.hLabel.Size = new System.Drawing.Size(42, 24);
            this.hLabel.TabIndex = 13;
            this.hLabel.Text = "N/A";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 524);
            this.Controls.Add(this.hLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.gaBtn);
            this.Controls.Add(this.lbsBtn);
            this.Controls.Add(this.saBtn);
            this.Controls.Add(this.hcBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.setQueenPos);
            this.Controls.Add(this.nTrackBar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chessBrd);
            this.Controls.Add(this.nLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nTrackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar nTrackBar;
        private System.Windows.Forms.Label nLabel;
        private System.Windows.Forms.Panel chessBrd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button setQueenPos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button hcBtn;
        private System.Windows.Forms.Button saBtn;
        private System.Windows.Forms.Button lbsBtn;
        private System.Windows.Forms.Button gaBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label hLabel;
    }
}

